declare const _default: {
    neovim: any;
    log4js: any;
    tslib: any;
    'socket.io': any;
    'msgpack-lite': any;
};
export default _default;
