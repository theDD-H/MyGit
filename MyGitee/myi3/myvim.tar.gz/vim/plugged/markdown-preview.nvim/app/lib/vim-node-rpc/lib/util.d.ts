export declare function getPort(): Promise<number>;
